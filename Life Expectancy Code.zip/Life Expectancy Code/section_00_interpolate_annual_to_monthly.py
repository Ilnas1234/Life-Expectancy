"""
section_00_interpolate_annual_to_monthly.py - Reproduce the monthly dataset from the annual anchors.

The annual World Bank / OWID values were assigned to January of each year and the remaining months were filled
by linear interpolation toward the next January (EViews was used originally; this script reproduces the same
transformation with pandas and verifies it against data/monthly_interpolated.xlsx). The final year (2022) is
carried forward because no later anchor exists. Also writes data/annual_indicators.csv (the 23 observed rows).
"""
import os
import numpy as np, pandas as pd
from utils import load_data, FEATURES, TARGET, DATA_PATH

def main():
    df = load_data()
    ann = df[df["Year"].dt.month == 1][["Year"] + FEATURES + [TARGET]].copy(); ann["Year"] = ann["Year"].dt.year
    ann.to_csv(os.path.join(os.path.dirname(DATA_PATH), "annual_indicators.csv"), index=False)
    idx = pd.date_range(f"{ann.Year.min()}-01-01", f"{ann.Year.max()}-12-01", freq="MS")
    monthly = ann.set_index(pd.to_datetime(ann.Year.astype(str) + "-01-01")).drop(columns="Year").reindex(idx)
    monthly = monthly.interpolate(method="linear").ffill()
    diff = np.abs(monthly.values - df[FEATURES + [TARGET]].values).max()
    print(f"{len(ann)} annual anchors -> {len(monthly)} monthly rows; max abs difference to shipped file = {diff:.2e}")
    assert diff < 1e-6, "Interpolation does not reproduce the shipped monthly dataset"

if __name__ == "__main__":
    main()
