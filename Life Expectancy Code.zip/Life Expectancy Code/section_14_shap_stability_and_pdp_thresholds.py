"""
section_14_shap_stability_and_pdp_thresholds.py - Stability of the SHAP ranking (manuscript Table 19) and
quantitative PDP transition points in raw units (manuscript Table 20).

SHAP: TreeExplainer (tree-path-dependent) on the 55 Protocol A test rows. Conditions: the three best hybrids,
SCA at all four population sizes, SCA with an added month-index feature, and SCA fitted on the 23 annual records.
PDP: scikit-learn partial_dependence (recursion method, 50-point grid) on the training rows.
"""
import os, pickle
import numpy as np, pandas as pd
import shap
from sklearn.preprocessing import MinMaxScaler
from sklearn.inspection import partial_dependence
from utils import scaled_split, annual_records, best_hybrid_params, FEATURES, CACHE_DIR, TAB_DIR
from baselines import make_hybrid

def shap_rank(model, Xs, feats):
    sv = shap.TreeExplainer(model).shap_values(Xs); return pd.Series(np.abs(sv).mean(0), index=feats)

def main():
    X_tr, X_te, y_tr, y_te, scaler, tr_i, te_i = scaled_split()
    hyb, pops = best_hybrid_params(); rk = {}
    for k, p in hyb.items(): rk[f"{k}-LSBoost (pop={pops[k]})"] = shap_rank(make_hybrid(p, 0).fit(X_tr, y_tr), X_te, FEATURES)
    cfg = pickle.load(open(os.path.join(CACHE_DIR, "optimization_results.pkl"), "rb"))
    for pop in (10, 30, 40):
        if ("SCA", pop) in cfg: rk[f"SCA-LSBoost (pop={pop})"] = shap_rank(make_hybrid(cfg[("SCA", pop)]["best_params"], 0).fit(X_tr, y_tr), X_te, FEATURES)
    n = len(tr_i) + len(te_i); Xt_tr = np.c_[X_tr, tr_i / (n - 1)]; Xt_te = np.c_[X_te, te_i / (n - 1)]
    rk["SCA-LSBoost + time index"] = shap_rank(make_hybrid(hyb["SCA"], 0).fit(Xt_tr, y_tr), Xt_te, FEATURES + ["TIME"])
    Xa, ya, _ = annual_records(); scA = MinMaxScaler().fit(Xa)
    rk["SCA-LSBoost (annual, n=23)"] = shap_rank(make_hybrid(hyb["SCA"], 0).fit(scA.transform(Xa), ya), scA.transform(Xa), FEATURES)
    RK = pd.DataFrame(rk).fillna(0).round(3); RK.to_csv(os.path.join(TAB_DIR, "table_19_shap_stability.csv")); print(RK)
    m = make_hybrid(hyb["SCA"], 0).fit(X_tr, y_tr); rows = []
    for f in ["UP", "EA", "NM", "CO2"]:
        j = FEATURES.index(f); pdp = partial_dependence(m, X_tr, [j], grid_resolution=50); g, v = pdp["grid_values"][0], pdp["average"][0]
        lo, hi = v[:5].mean(), v[-5:].mean(); mid = g[np.argmin(np.abs(v - (lo + hi) / 2))]
        x10 = g[np.argmax(v >= lo + 0.1 * (hi - lo))] if hi > lo else g[np.argmax(v <= lo + 0.1 * (hi - lo))]
        x90 = g[np.argmax(v >= lo + 0.9 * (hi - lo))] if hi > lo else g[np.argmax(v <= lo + 0.9 * (hi - lo))]
        raw = lambda x: scaler.data_min_[j] + x * scaler.data_range_[j]
        rows.append({"Feature": f, "PDP low plateau": round(lo, 3), "PDP high plateau": round(hi, 3), "Range (years)": round(hi - lo, 3),
                     "Midpoint (scaled)": round(mid, 3), "Midpoint (raw units)": round(raw(mid), 3), "10-90% band (raw)": f"{raw(x10):.3f} – {raw(x90):.3f}"})
    out = pd.DataFrame(rows); out.to_csv(os.path.join(TAB_DIR, "table_20_pdp_thresholds.csv"), index=False); print(out.to_string(index=False))

if __name__ == "__main__":
    main()
